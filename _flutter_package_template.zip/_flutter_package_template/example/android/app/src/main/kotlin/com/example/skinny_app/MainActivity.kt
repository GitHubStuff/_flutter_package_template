package com.replce_domanin.empty_package

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
