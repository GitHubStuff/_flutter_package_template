import 'package:empty_package/empty_package.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

mixin DictionaryEnumMixin {
  String lookup(DictionaryEnum item, {required BuildContext of}) {
    switch (item) {
      case DictionaryEnum.helloWorld:
        return AppLocalizations.of(of)!.helloWorld;
    }
  }
}
