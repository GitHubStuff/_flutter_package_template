import 'package:extensions_package/extensions_package.dart';
import 'package:flutter/material.dart';
import 'package:rae_localization_package/rae_localization_package.dart';
import 'package:theme_management/theme_management.dart';

/// Rotates through the localization enums
class LocalizationInformation {
  static List<Type> types = [
    EmotionLocalization,
    GarminLocalization,
    Greeting,
    LevelOfSymptomLocalization,
    RAELocalization,
  ];
  LocalizationInformation({required BuildContext context, int? enumIndex}) {
    final dynamic localizationIdentifier = LocalizationInformation.types[LocalizationInformation.localizationIndex];
    String key = '';
    String value = '';
    int index = enumIndex ?? 0;
    switch (localizationIdentifier) {
      case RAELocalization:
        length = RAELocalization.values.length;
        key = RAELocalization.values[index].name;
        value = RAELocalization.values[index].text;
        break;
      case EmotionLocalization:
        length = EmotionLocalization.values.length;
        key = EmotionLocalization.values[index].name;
        value = EmotionLocalization.values[index].text;
        break;
      case Greeting:
        length = Greeting.values.length;
        key = Greeting.values[index].name;
        value = Greeting.values[index].text;
        break;
      case GarminLocalization:
        length = GarminLocalization.values.length;
        key = GarminLocalization.values[index].name;
        value = GarminLocalization.values[index].text;
        break;
      case LevelOfSymptomLocalization:
        length = LevelOfSymptomLocalization.values.length;
        key = LevelOfSymptomLocalization.values[index].name;
        value = LevelOfSymptomLocalization.values[index].text;
        break;
      default:
        throw FlutterError('Unknown localizationIdentifier ${localizationIdentifier.toString()}');
    }
    listTile = Padding(
      padding: const EdgeInsets.all(2.0),
      child: Container(
        child: ListTile(
          title: Text(key).fontSize(20),
          subtitle: Text(value).fontSize(16),
        ),
      )
          .background(ThemeColors(
            dark: Colors.black87,
            light: Colors.yellow.shade50,
          ).of(context))
          .borderAll(Colors.green),
    );
  }

  ///
  late int length;
  late Widget listTile;

  ///
  static Widget at({required int index, required BuildContext context}) => LocalizationInformation(
        context: context,
        enumIndex: index,
      ).listTile;
  static int localizationIndex = 0;

  static Text buttonText() => Text(types[localizationIndex].toString()).fontSize(18.0);

  static void next() => localizationIndex = (localizationIndex + 1) == types.length ? 0 : ++localizationIndex;
}
