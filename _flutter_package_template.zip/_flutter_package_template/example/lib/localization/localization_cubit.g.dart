// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'localization_cubit.dart';

// **************************************************************************
// LocalizeCubitGenerator
// **************************************************************************

//MARK: Helper class XYXLanguage for getting/setting Locale
class XYXLanguage {
  static Cubit<XYXLocalizationState> get cubit => _XYXLocalizationCubit.cubit;
  static Future<void> setup({Locale? locale}) =>
      _XYXLocalizationCubit.setup(locale: locale);
  static Locale get locale => _XYXLocalizationCubit.locale;
  static set locale(Locale newLocale) =>
      _XYXLocalizationCubit.locale = newLocale;
  static String translate(XYXLocalization token, {Locale? locale}) =>
      token.byLocale(locale ?? _XYXLocalizationCubit.locale);
}

//MARK: Cubit
class _XYXLocalizationCubit extends Cubit<XYXLocalizationState> {
  static final _XYXLocalizationCubit _singleton =
      _XYXLocalizationCubit._internal();
  factory _XYXLocalizationCubit() => _singleton;
  _XYXLocalizationCubit._internal() : super(XYXLocaleInitial());
  static _XYXLocalizationCubit _localizationCubit = _XYXLocalizationCubit();
  static _XYXLocalizationCubit get cubit => _localizationCubit;

  bool _usingHiveStore = false;

  static Future<void> setup({Locale? locale}) async {
    _localizationCubit._locale = locale;
    _localizationCubit._usingHiveStore = (locale == null);
    if (_localizationCubit._usingHiveStore) await XYXHiveManager.setup();
  }

  //MARK: Locale
  Locale? _locale;
  static Locale get locale {
    if (_localizationCubit._usingHiveStore)
      _localizationCubit._locale = XYXHiveManager._get();
    return _localizationCubit._locale ?? Locale('en');
  }

  static set locale(Locale locale) {
    _localizationCubit._locale = locale;
    if (_localizationCubit._usingHiveStore)
      XYXHiveManager._save(locale: locale);
    _localizationCubit.emit(XYXLocaleUpdated(locale));
  }
}

//MARK: State
@immutable
abstract class XYXLocalizationState {}

class XYXLocaleInitial extends XYXLocalizationState {}

class XYXLocaleUpdated extends XYXLocalizationState {
  final Locale updatedLocale;
  XYXLocaleUpdated(this.updatedLocale);
}

//MARK: Hive
bool _isLocaleHiveSetup = false;

class XYXHiveManager {
  static const _boxName = 'com.xyxlocalization.hive.saved_locale.language_code';
  static Box? _box;
  static Future<void> setup() async {
    try {
      await Hive.initFlutter();
      _box = await Hive.openBox<String>(_boxName);
    } on NullThrownError {
    } on MissingPluginException {
    } catch (e) {
      throw FlutterError(e.toString());
    }
    _isLocaleHiveSetup = true;
  }

  static Locale _save({required Locale locale}) {
    if (!_isLocaleHiveSetup)
      throw FlutterError('XYXLocalizationCubit.setupLocalization not called!');
    final String languageCode = locale.languageCode;
    _box?.put(_boxName, languageCode);
    return Locale(languageCode);
  }

  static Locale _get() {
    if (!_isLocaleHiveSetup)
      throw FlutterError('XYXLocalizationCubit.setupLocalization not called!');
    String storedValue =
        _box?.get(_boxName, defaultValue: 'en'); // 'en' - english
    return Locale(storedValue);
  }
}
