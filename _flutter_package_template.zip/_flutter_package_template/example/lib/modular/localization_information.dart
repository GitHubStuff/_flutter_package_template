import 'package:extensions/extensions.dart';
import 'package:flutter/material.dart';

import '../template/localization/localization/build/dictionary_enum.dart';
import '../template/theme/lib/theme_colors.dart';

/// Rotates through the localization enums, a way to create a widget that shows locale(s)
class LocalizationInformation {
  static List<Type> types = [
    SharedEnum,
  ];

  LocalizationInformation({required BuildContext context, int? enumIndex}) {
    final dynamic localizationIdentifier = LocalizationInformation.types[LocalizationInformation.localizationIndex];
    String key = '';
    String value = '';
    int index = enumIndex ?? 0;
    switch (localizationIdentifier) {
      case SharedEnum:
        length = SharedEnum.values.length;
        key = SharedEnum.values[index].name;
        value = SharedEnum.values[index].text;
        break;

      default:
        throw FlutterError('Unknown localizationIdentifier ${localizationIdentifier.toString()}');
    }
    listTile = Padding(
      padding: const EdgeInsets.all(2.0),
      child: Container(
        child: ListTile(
          title: Text(key).fontSize(20),
          subtitle: Text(value).fontSize(16),
        ),
      )
          .background(ThemeColors(
            dark: Colors.black87,
            light: Colors.yellow.shade50,
          ).of(context))
          .borderAll(Colors.green),
    );
  }

  ///
  late int length;
  late Widget listTile;

  ///
  static Widget at({required int index, required BuildContext context}) => LocalizationInformation(
        context: context,
        enumIndex: index,
      ).listTile;
  static int localizationIndex = 0;

  static Text buttonText() => Text(types[localizationIndex].toString()).fontSize(18.0);

  static void next() => localizationIndex = (localizationIndex + 1) == types.length ? 0 : ++localizationIndex;
}

///
