import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:theme_management/theme_management.dart';
import 'package:xample/cubit/localization_cubit.dart';

class ThemeAndMaterialWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _localeWidget();
  }

  /// Widget wrapper to enclose the BlocBuilder that manages state for changing lanaguage/locale
  Widget _localeWidget() {
    XYXLocalizationCubit localeCubit = Modular.get<XYXLocalizationCubit>();
    return BlocBuilder<XYXLocalizationCubit, XYXLocalizationState>(
      bloc: localeCubit,
      builder: (_, state) => _materialAppBloc(localeCubit.locale),
    );
  }

  /// Widget wrapper to enclose switching dark/light mode themes of the MaterialApp
  Widget _materialAppBloc(Locale? locale) {
    return BlocBuilder<ThemeModeCubit, ThemeModeState>(
        bloc: ThemeManagement.themeModeCubit,
        builder: (_, state) {
          return MaterialApp(
            title: 'Flutter Demo',
            locale: locale,
            theme: ThemeManagement.lightTheme,
            darkTheme: ThemeManagement.darkTheme,
            themeMode: ThemeManagement.themeMode,
            initialRoute: '/',
            localizationsDelegates: [
              AppLocalizations.delegate, //Used to translate strings in /l10n/app_en.arb or /l10n/app_es.arb files
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: [
              const Locale('de', ''), // German, no country code
              const Locale('en', ''), // English, no country code
              const Locale('es', ''), // Spanish, no country code
            ],
          ).modular();
        });
  }
}
