import 'package:extensions/extensions.dart';
import 'package:flutter/material.dart';

import '../mixin/widget_tree_mixin.dart';
import 'localization_information.dart';
//import 'package:xample/package/mixins/popover_mixin.dart';

class ScaffoldWidget extends StatefulWidget {
  ScaffoldWidget({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _ScaffoldWidget createState() => _ScaffoldWidget();
}

class _ScaffoldWidget extends ObservingStatefulWidget<ScaffoldWidget> with PopoverMixin, WidgetTreeMixin {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
          actions: [],
        ),
        body: rebuildTreeOnThemeOrLanguageChange(body: _body),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            showWidgetDialog(
              context,
              child: Text('Does Nothing').fontSize(46.0),
              displayDuration: Duration(seconds: 2),
            );
          },
          tooltip: 'Increment',
          child: Icon(Icons.add),
        ),
      );

  Widget _body(BuildContext context) {
    return Column(
      children: <Widget>[
        SizedBox(height: 4),
        ElevatedButton(
            onPressed: () {
              setState(() {
                LocalizationInformation.next();
              });
            },
            child: LocalizationInformation.buttonText()),
        Expanded(
          flex: 2,
          child: ListView.builder(
            itemCount: LocalizationInformation(context: context).length,
            itemBuilder: (context, index) => LocalizationInformation.at(index: index, context: context),
          ),
        ),
        SizedBox(height: 72.0),
      ],
    );
  }
}
