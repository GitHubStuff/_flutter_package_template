import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../brightness_type.dart';
import '../cubit/theme_mode_cubit.dart';
import '../theme_data/text_key.dart';
import '../theme_management.dart';
import '../theme_mode_extensions.dart';

class ThemeClass extends StatelessWidget {
  ThemeClass({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) => theme(context);
}

Widget theme(BuildContext context) => Container(
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            BlocBuilder<ThemeModeCubit, ThemeModeState>(
                bloc: ThemeManagement.cubit,
                builder: (_, state) {
                  return Text(
                    'ThemeMode: ${ThemeManagement.themeMode.brightnessMode(context).name}',
                    style: TextStyle(fontSize: TextKey.headline6.fontSize),
                  );
                }),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(onPressed: () => ThemeManagement.themeMode = ThemeMode.dark, child: Text('Dark')),
                ElevatedButton(onPressed: () => ThemeManagement.themeMode = ThemeMode.light, child: Text('Light')),
                ElevatedButton(onPressed: () => ThemeManagement.themeMode = ThemeMode.system, child: Text('System')),
              ],
            ),
            _themeIcons(context),
          ],
        ),
      ),
    );

Widget _themeIcons(BuildContext context) {
  return Column(
    children: [
      Row(
        children: [
          Padding(
            padding: EdgeInsets.only(left: 8, right: 6, bottom: 2),
            child: BrightnessType.appDark.icon(context),
          ),
          Text(BrightnessType.appDark.name),
          Padding(
            padding: EdgeInsets.only(left: 8, right: 6, bottom: 2),
            child: BrightnessType.appLight.icon(context),
          ),
          Text(BrightnessType.appLight.name),
        ],
      ),
      Row(
        children: [
          Padding(
            padding: EdgeInsets.only(left: 8, right: 6, bottom: 2),
            child: BrightnessType.systemDark.icon(context),
          ),
          Text(BrightnessType.systemDark.name),
          Padding(
            padding: EdgeInsets.only(left: 8, right: 6, bottom: 2),
            child: BrightnessType.systemLight.icon(context),
          ),
          Text(BrightnessType.systemLight.name),
        ],
      ),
    ],
  );
}
