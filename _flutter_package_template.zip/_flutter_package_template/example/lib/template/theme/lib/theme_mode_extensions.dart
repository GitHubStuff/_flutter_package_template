import 'package:flutter/material.dart';

import 'brightness_type.dart';

extension ThemeModeBrightnessTypeExtension on ThemeMode {
  Brightness of(BuildContext context) => MediaQuery.of(context).platformBrightness;
  BrightnessType brightnessMode(BuildContext context) {
    switch (this) {
      case ThemeMode.dark:
        return BrightnessType.appDark;
      case ThemeMode.light:
        return BrightnessType.appLight;
      case ThemeMode.system:
        return of(context) == Brightness.dark ? BrightnessType.systemDark : BrightnessType.systemLight;
    }
  }
}
