import 'package:extensions/extensions.dart';
import 'package:flutter/material.dart';
import 'package:xample/mixin/widget_tree_mixin.dart';

import '../localization/language/lib/language.dart';
import '../localization/localization/build/dictionary_enum.dart';

class Localization extends StatelessWidget with PopoverMixin, WidgetTreeMixin {
  Localization({Key? key}) : super(key: key);

  Widget build(BuildContext context) => rebuildTreeOnThemeOrLanguageChange(body: _language);
}

Widget _language() {
  return Container(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(SharedEnum.hello.text).fontSize(22.0), //Example of localization
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Wrap(
            spacing: 3.0,
            children: [
              ElevatedButton(onPressed: () => Language.locale = Locale('en'), child: Text('English')),
              ElevatedButton(onPressed: () => Language.locale = Locale('es'), child: Text('Spanish')),
              ElevatedButton(onPressed: () => Language.locale = Locale('de'), child: Text('German')),
              ElevatedButton(onPressed: () => Language.locale = Locale('ko'), child: Text('Korean')),
            ],
          ),
        ),
      ],
    ),
  ).borderAll(Colors.blueAccent).paddingAll(3.0);
}
