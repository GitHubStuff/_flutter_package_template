# scaffold_extensions

When creating scaffolds/screens with background images or gradients, this will copy a Scaffold() and set the
transparency so background images/gradients appear

```dart
Scaffold copyWith({Key? key, Color backgroundColor = Colors.transparent})
