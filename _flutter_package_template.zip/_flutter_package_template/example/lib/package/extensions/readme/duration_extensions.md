# extension DurationExtension on Duration

## Summary

```dart
/// Add Duration to duration
Duration add(Duration amount)

/// Substract Duration from duration
Duration sub(Duration amount)
```

## Final Note

Be kind to each other
