# extension TextExtensions on Text

## Summary

```dart
  // Set the text's color
  Text textColor(Color color)

  // Set the text's fontSize
  Text fontSize(double fontSize)
```

## Final Note

Be kind to each other
