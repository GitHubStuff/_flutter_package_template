# extension ThemeModeExtensions on ThemeMode

## Usage

```dart
/// Returns the bright-ness of the ThemeMode
Brightness of(BuildContext context);
```

## Final Note

Be kind to each other
