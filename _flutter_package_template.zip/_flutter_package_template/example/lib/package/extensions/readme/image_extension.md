# extension ImageExtension on Image

## Summary

```dart
  Widget get leftRotation  //Rotate -90 degrees
  Widget get rightRotation //Rotate 90 degrees
  Widget get upsideDownRotation //Rotate 180 degrees
  Widget rotate({required double percentage}) // Rotation percentage -1.0 to 1.0
```

## Final Note

Be kind to each other
