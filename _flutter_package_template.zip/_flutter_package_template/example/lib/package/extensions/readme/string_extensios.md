# extension StringExtensions on String

## Summary

```dart
/// Translate upper case text to "_?"   ?: uppercase character
/// Example: Convert 'SampleCamelCase' to 'sample_camel_case'
String unCamelCase()

/// throws error if n < 0, returns 'this' if n >= this.length, otherwise return last 'n' characters
String lastCharacters(int n)
```

## Final Note

Be kind to each other
