# Package - April 2022

Collection of package that can be included in most projects/packages

## Getting Started

* code_generation

  This is the code generation for Localization, and persisting classes/objects using HIVE

  If added to a project/package make sure they are 'path'-ed correctly in **dependencies** and
  **dev_dependencies** in *pubspec.yaml*

* extensions

  Collection of extensions on classes. This collection is intended to be treated as a package
  within the main project (aka a 'sub-package')

## Final note

Be kind to each other!
