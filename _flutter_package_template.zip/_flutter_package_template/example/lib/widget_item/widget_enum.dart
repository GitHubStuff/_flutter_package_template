enum WidgetEnum {
  screen,
  widget,
}
