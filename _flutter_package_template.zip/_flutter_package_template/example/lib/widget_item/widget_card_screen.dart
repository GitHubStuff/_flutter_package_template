import 'package:extensions/extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';

import '../main.dart';
import '../mixin/widget_tree_mixin.dart';
import 'widget_enum.dart';
import 'widget_item.dart';

class WidgetCardScreen extends StatelessWidget with PopoverMixin, WidgetTreeMixin {
  WidgetCardScreen({Key? key}) : super(key: key);

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Widgets'),
        actions: [],
      ),
      body: rebuildTreeOnThemeOrLanguageChange(body: _body),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showWidgetDialog(
            context,
            child: Text('Does Nothing').fontSize(46.0),
            displayDuration: Duration(seconds: 2),
          );
        },
        tooltip: 'Nothing',
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _body() {
    return ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          WidgetItem item = items[index];
          final Color color = (index % 2 == 0) ? Colors.white70 : Colors.white60;
          return GestureDetector(
            onTap: () {
              switch (item.widgetEnum) {
                case WidgetEnum.screen:
                  Modular.to.push(MaterialPageRoute(builder: (context) => item.child));
                  break;
                case WidgetEnum.widget:
                  Modular.to.push(MaterialPageRoute(builder: (context) => WidgetScreen(widgetItem: item)));
                  break;
              }
            },
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: Card(
                color: color,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(item.title),
                ),
              ),
            ),
          );
        });
  }
}
