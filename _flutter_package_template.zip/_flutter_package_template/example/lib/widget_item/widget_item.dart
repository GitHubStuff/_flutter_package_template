import 'package:extensions/extensions.dart';
import 'package:flutter/material.dart';

import '../mixin/widget_tree_mixin.dart';
import 'widget_enum.dart';

class WidgetItem {
  final WidgetEnum widgetEnum;
  final Widget child;
  final String title;
  WidgetItem({required this.widgetEnum, required this.child, required this.title});
}

class WidgetScreen extends StatefulWidget {
  final WidgetItem widgetItem;
  WidgetScreen({Key? key, required this.widgetItem}) : super(key: key);
  _WidgetScreen createState() => _WidgetScreen();
}

class _WidgetScreen extends ObservingStatefulWidget<WidgetScreen> with PopoverMixin, WidgetTreeMixin {
  @override
  Widget build(BuildContext context) => _scaffold();

  Widget _scaffold() {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.widgetItem.title),
        actions: [],
      ),
      body: widget.widgetItem.child,
    );
  }
}
