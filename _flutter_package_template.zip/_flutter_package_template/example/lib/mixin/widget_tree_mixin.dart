import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../template/localization/language/lib/language.dart';
import '../template/theme/lib/theme_management.dart';

typedef _ContextWidget = Widget Function(BuildContext context);
typedef _ContextFreeWidget = Widget Function();

mixin WidgetTreeMixin {
  Widget backgroundImageWidget({required Widget child, required ImageProvider imageProvider}) => Container(
        decoration: BoxDecoration(image: DecorationImage(image: imageProvider, fit: BoxFit.cover)),
        child: child,
      );

  Widget rebuildTreeOnThemeOrLanguageChange({required dynamic body}) {
    assert(body is _ContextWidget || body is _ContextFreeWidget);
    return BlocBuilder(
      bloc: Language.cubit,
      builder: (context, _) => BlocBuilder(
        bloc: ThemeManagement.cubit,
        builder: (context, _) {
          if (body is _ContextWidget) return body(context);
          if (body is _ContextFreeWidget) return body();
          throw FlutterError('Unknown child type: ${body.toString()}');
        },
      ),
    );
  }
}
