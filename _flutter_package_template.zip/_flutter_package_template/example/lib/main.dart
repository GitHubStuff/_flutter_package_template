import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_modular/flutter_modular.dart';

import 'modular/app_module.dart';
import 'modular/scaffold_widget.dart';
import 'modular/theme_and_material_widget.dart';
import 'template/localization/language/lib/language.dart';
import 'template/theme/lib/theme_management.dart';
import 'template/theme/lib/widgets/themes.dart';
import 'template/widgets/localization.dart';
import 'widget_item/widget_enum.dart';
import 'widget_item/widget_item.dart';

List<WidgetItem> items = [
  WidgetItem(title: 'Languages', child: Localization(), widgetEnum: WidgetEnum.widget),
  WidgetItem(title: 'Scaffold', child: ScaffoldWidget(title: 'Scaffold'), widgetEnum: WidgetEnum.screen),
  WidgetItem(title: 'Themes', child: ThemeClass(), widgetEnum: WidgetEnum.widget),
];
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  /// Enable theme changes/monitoring by creating a 'hive' object to persist information
  await ThemeManagement.setup();
  await Language.setup();

  /// Set BLoC observer for additional console messages

  BlocOverrides.runZoned(
    () => runApp(ModularApp(
      module: AppModule(),
      child: ThemeAndMaterialWidget(),
    )),
    blocObserver: null, //SimpleBlocObserver(),
    // NOTE: For release blocObserver: null,
  );
}
