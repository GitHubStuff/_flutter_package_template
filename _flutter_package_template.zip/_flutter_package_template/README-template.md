# empty_package

This is a template for the README.md. Replace the *README.md* with this, and fill in empty/missing details.

## Install

```text
dependencies:
  empty_package:
    git:
      url: https://github.com/GitHubStuff/empty_package.git
```

***- OR -***

```text
dependencies:
  empty_package:
    git:
      url: https://github.com/RAE-Health/empty_package.git
```

## Import

```dart
import 'package:empty_package/empty_package.dart';
```

## Usage

TODO: Provide details/examples on usage.

## Final Note

Be kind to each other
