# empty_package

This is a template for the README.md. Replace the *README.md* with this, and fill in empty/missing details.

## Install

```text
dependencies:
  empty_package:
    git:
      url: {url of github repo}
```

## Import

```dart
import 'package:empty_packge/empty_package.dart';
```

## Usage

Provide details/examples on usage.

## Final Note

Be kind to each other
