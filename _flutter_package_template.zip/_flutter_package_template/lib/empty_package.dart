library empty_package;  // search/replace 'empty_package' and rename this 'empty_package.dart' to the plug-in name
