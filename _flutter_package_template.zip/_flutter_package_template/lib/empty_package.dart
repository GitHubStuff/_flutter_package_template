library empty_package;

export 'src/empty.dart';
