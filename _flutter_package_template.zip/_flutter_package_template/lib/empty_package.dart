 /// search/replace 'empty_package' and rename this 'empty_package.dart' to the plug-in name
 /// see README.md for complete instructions
library empty_package;

export 'localization/dictionary_enum.dart';
