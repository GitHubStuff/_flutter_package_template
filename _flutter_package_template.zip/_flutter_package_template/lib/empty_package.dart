library empty_package;

export 'src/cubit/localization_cubit.dart';
export 'localization/dictionary_enum.dart';
