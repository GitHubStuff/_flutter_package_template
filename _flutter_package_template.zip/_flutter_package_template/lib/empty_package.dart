library empty_package;

export 'src/dictionary_enum.dart';
