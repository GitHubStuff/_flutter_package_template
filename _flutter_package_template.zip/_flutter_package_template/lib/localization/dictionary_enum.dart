// Search/Replace DictionaryEnum with a name suitable for your app

enum DictionaryEnum {
  helloWorld,
}
