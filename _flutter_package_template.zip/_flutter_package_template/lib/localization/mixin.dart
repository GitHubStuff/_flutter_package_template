import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/package_localizations.dart';

import 'dictionary_enum.dart';

mixin DictionaryEnumMixin {
  String lookup(DictionaryEnum item, {required BuildContext of}) {
    switch (item) {
      case DictionaryEnum.helloWorld:
        return AppLocalizations.of(of)!.helloWorld;
    }
  }
}
