/// Search/Replace "DictionaryEnum" with a name suitable for your app
/// Rename "dictionary_enum.dart" to the new name

enum DictionaryEnum {
  helloWorld,
}
