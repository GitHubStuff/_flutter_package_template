// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'localization_cubit.dart';

// **************************************************************************
// LocalizeCubitGenerator
// **************************************************************************

class YYYLocalizationCubit extends Cubit<YYYLocalizationState> {
  static final YYYLocalizationCubit _singleton =
      YYYLocalizationCubit._internal();
  factory YYYLocalizationCubit() => _singleton;
  YYYLocalizationCubit._internal() : super(YYYLocaleInitial());
  static YYYLocalizationCubit _localizationCubit = YYYLocalizationCubit();
  static YYYLocalizationCubit get cubit => _localizationCubit;

  static Future<void> setup({Locale? locale}) async {
    _localizationCubit._locale = locale;
    _localizationCubit._usingHivePersistence = (locale == null);
    if (_localizationCubit._usingHivePersistence) await YYYHiveManager.setup();
  }

  Locale? _locale;
  bool _usingHivePersistence = false;
  Locale get locale {
    if (_localizationCubit._usingHivePersistence)
      _locale = YYYHiveManager.get();
    return _locale ?? Locale('en');
  }

  set locale(Locale locale) {
    _locale = locale;
    if (_localizationCubit._usingHivePersistence)
      YYYHiveManager.save(locale: locale);
    _localizationCubit.emit(YYYLocaleUpdated(locale));
  }
}

//MARK: State
@immutable
abstract class YYYLocalizationState {}

class YYYLocaleInitial extends YYYLocalizationState {}

class YYYLocaleUpdated extends YYYLocalizationState {
  final Locale updatedLocale;
  YYYLocaleUpdated(this.updatedLocale);
}

//MARK: Hive
bool _isLocaleHiveSetup = false;

class YYYHiveManager {
  static const _boxName = 'com.yyylocalization.hive.saved_locale.language_code';
  static Box? _box;
  static Future<void> setup() async {
    try {
      await Hive.initFlutter();
      _box = await Hive.openBox<String>(_boxName);
    } on NullThrownError {
    } on MissingPluginException {
    } catch (e) {
      throw FlutterError(e.toString());
    }
    _isLocaleHiveSetup = true;
  }

  static Locale save({required Locale locale}) {
    if (!_isLocaleHiveSetup)
      throw FlutterError('YYYLocalizationCubit.setupLocalization not called!');
    final String languageCode = locale.languageCode;
    _box?.put(_boxName, languageCode);
    return Locale(languageCode);
  }

  static Locale get() {
    if (!_isLocaleHiveSetup)
      throw FlutterError('YYYLocalizationCubit.setupLocalization not called!');
    String storedValue =
        _box?.get(_boxName, defaultValue: 'en'); // 'en' - english
    return Locale(storedValue);
  }
}
